﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WIzytowka
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            f.w_imie = imie.Text;
            f.w_nazwisko = nazwisko.Text;
            f.w_adres = ulica.Text;
            f.w_miasto = kodmiasto.Text;
            f.w_telefon = tel.Text;
            f.w_email = mail.Text;
            f.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void key_c(object sender, KeyPressEventArgs e)
        {
            
        }
    }
}
