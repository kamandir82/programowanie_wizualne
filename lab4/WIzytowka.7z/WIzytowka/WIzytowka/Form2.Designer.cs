﻿namespace WIzytowka
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.wiersz1 = new System.Windows.Forms.Label();
            this.wiersz2 = new System.Windows.Forms.Label();
            this.wiersz3 = new System.Windows.Forms.Label();
            this.wiersz4 = new System.Windows.Forms.Label();
            this.wiersz5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // wiersz1
            // 
            this.wiersz1.AutoSize = true;
            this.wiersz1.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.wiersz1.Location = new System.Drawing.Point(209, 67);
            this.wiersz1.Name = "wiersz1";
            this.wiersz1.Size = new System.Drawing.Size(373, 29);
            this.wiersz1.TabIndex = 0;
            this.wiersz1.Text = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
            this.wiersz1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.wiersz1.MouseLeave += new System.EventHandler(this.wiersz1_ML);
            this.wiersz1.MouseHover += new System.EventHandler(this.wiersz1_MH);
            // 
            // wiersz2
            // 
            this.wiersz2.AutoSize = true;
            this.wiersz2.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.wiersz2.Location = new System.Drawing.Point(209, 136);
            this.wiersz2.Name = "wiersz2";
            this.wiersz2.Size = new System.Drawing.Size(373, 29);
            this.wiersz2.TabIndex = 1;
            this.wiersz2.Text = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
            this.wiersz2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // wiersz3
            // 
            this.wiersz3.AutoSize = true;
            this.wiersz3.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.wiersz3.Location = new System.Drawing.Point(209, 207);
            this.wiersz3.Name = "wiersz3";
            this.wiersz3.Size = new System.Drawing.Size(373, 29);
            this.wiersz3.TabIndex = 2;
            this.wiersz3.Text = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
            this.wiersz3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // wiersz4
            // 
            this.wiersz4.AutoSize = true;
            this.wiersz4.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.wiersz4.Location = new System.Drawing.Point(209, 277);
            this.wiersz4.Name = "wiersz4";
            this.wiersz4.Size = new System.Drawing.Size(373, 29);
            this.wiersz4.TabIndex = 3;
            this.wiersz4.Text = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
            this.wiersz4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // wiersz5
            // 
            this.wiersz5.AutoSize = true;
            this.wiersz5.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.wiersz5.Location = new System.Drawing.Point(209, 351);
            this.wiersz5.Name = "wiersz5";
            this.wiersz5.Size = new System.Drawing.Size(373, 29);
            this.wiersz5.TabIndex = 4;
            this.wiersz5.Text = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
            this.wiersz5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.wiersz5);
            this.Controls.Add(this.wiersz4);
            this.Controls.Add(this.wiersz3);
            this.Controls.Add(this.wiersz2);
            this.Controls.Add(this.wiersz1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.key_q);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label wiersz1;
        private System.Windows.Forms.Label wiersz2;
        private System.Windows.Forms.Label wiersz3;
        private System.Windows.Forms.Label wiersz4;
        private System.Windows.Forms.Label wiersz5;
    }
}