﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WIzytowka
{
    public partial class Form2 : Form
    {
        public string w_imie, w_nazwisko, w_adres, w_miasto, w_telefon, w_email;

        private void key_q(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 'q') Close();
        }

        private void wiersz1_ML(object sender, EventArgs e)
        {
            wiersz1.ForeColor = Color.Black;
        }

        private void wiersz1_MH(object sender, EventArgs e)
        {
            wiersz1.ForeColor = Color.Red;
        }

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            wiersz1.Text = w_imie+" "+w_nazwisko;
            wiersz2.Text = "ul. " + w_adres;
            wiersz3.Text = w_miasto;
            wiersz4.Text = w_telefon;
            wiersz5.Text = w_email;

        }
    }
}
