﻿namespace WIzytowka
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.imie = new System.Windows.Forms.TextBox();
            this.nazwisko = new System.Windows.Forms.TextBox();
            this.ulica = new System.Windows.Forms.TextBox();
            this.kodmiasto = new System.Windows.Forms.TextBox();
            this.tel = new System.Windows.Forms.TextBox();
            this.mail = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.kod_miasto = new System.Windows.Forms.Label();
            this.telefon = new System.Windows.Forms.Label();
            this.email = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // imie
            // 
            this.imie.Location = new System.Drawing.Point(86, 145);
            this.imie.Name = "imie";
            this.imie.Size = new System.Drawing.Size(100, 22);
            this.imie.TabIndex = 0;
            // 
            // nazwisko
            // 
            this.nazwisko.Location = new System.Drawing.Point(86, 219);
            this.nazwisko.Name = "nazwisko";
            this.nazwisko.Size = new System.Drawing.Size(100, 22);
            this.nazwisko.TabIndex = 1;
            // 
            // ulica
            // 
            this.ulica.Location = new System.Drawing.Point(86, 296);
            this.ulica.Name = "ulica";
            this.ulica.Size = new System.Drawing.Size(203, 22);
            this.ulica.TabIndex = 2;
            // 
            // kodmiasto
            // 
            this.kodmiasto.Location = new System.Drawing.Point(86, 376);
            this.kodmiasto.Name = "kodmiasto";
            this.kodmiasto.Size = new System.Drawing.Size(149, 22);
            this.kodmiasto.TabIndex = 3;
            // 
            // tel
            // 
            this.tel.Location = new System.Drawing.Point(347, 219);
            this.tel.Name = "tel";
            this.tel.Size = new System.Drawing.Size(131, 22);
            this.tel.TabIndex = 4;
            // 
            // mail
            // 
            this.mail.Location = new System.Drawing.Point(347, 296);
            this.mail.Name = "mail";
            this.mail.Size = new System.Drawing.Size(131, 22);
            this.mail.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(86, 122);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 17);
            this.label1.TabIndex = 6;
            this.label1.Text = "Imię:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(86, 197);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 17);
            this.label2.TabIndex = 7;
            this.label2.Text = "Nazwisko:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(83, 276);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(206, 17);
            this.label3.TabIndex = 8;
            this.label3.Text = "Ulica / nr domu / nr mieszkania:";
            // 
            // kod_miasto
            // 
            this.kod_miasto.AutoSize = true;
            this.kod_miasto.Location = new System.Drawing.Point(83, 353);
            this.kod_miasto.Name = "kod_miasto";
            this.kod_miasto.Size = new System.Drawing.Size(152, 17);
            this.kod_miasto.TabIndex = 9;
            this.kod_miasto.Text = "Kod pocztowy / miasto:";
            // 
            // telefon
            // 
            this.telefon.AutoSize = true;
            this.telefon.Location = new System.Drawing.Point(344, 197);
            this.telefon.Name = "telefon";
            this.telefon.Size = new System.Drawing.Size(134, 17);
            this.telefon.TabIndex = 10;
            this.telefon.Text = "Telefon komórkowy:";
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.Location = new System.Drawing.Point(344, 276);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(91, 17);
            this.email.TabIndex = 11;
            this.email.Text = "Adres e-mail:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(80, 64);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(240, 32);
            this.label4.TabIndex = 12;
            this.label4.Text = "WYPEŁNIJ DANE";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(606, 376);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(158, 51);
            this.button1.TabIndex = 13;
            this.button1.Text = "GENERUJ WIZYTÓWKĘ";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WIzytowka.Properties.Resources.os_kali;
            this.pictureBox1.Location = new System.Drawing.Point(606, 64);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(111, 103);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.email);
            this.Controls.Add(this.telefon);
            this.Controls.Add(this.kod_miasto);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.mail);
            this.Controls.Add(this.tel);
            this.Controls.Add(this.kodmiasto);
            this.Controls.Add(this.ulica);
            this.Controls.Add(this.nazwisko);
            this.Controls.Add(this.imie);
            this.Name = "Form1";
            this.Text = "WIZYTÓWKA";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.key_c);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox imie;
        private System.Windows.Forms.TextBox nazwisko;
        private System.Windows.Forms.TextBox ulica;
        private System.Windows.Forms.TextBox kodmiasto;
        private System.Windows.Forms.TextBox tel;
        private System.Windows.Forms.TextBox mail;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label kod_miasto;
        private System.Windows.Forms.Label telefon;
        private System.Windows.Forms.Label email;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

